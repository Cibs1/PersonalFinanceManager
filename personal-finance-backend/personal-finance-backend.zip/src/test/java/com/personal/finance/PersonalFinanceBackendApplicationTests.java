package com.personal.finance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFinanceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
